import 'package:flutter/material.dart';

class CustomColors {
  static const cst1 = const Color(0xFF11559E);
  static const cst2 = const Color(0xFF30D4E3);
  static const cst3 = const Color(0xFFE4F2F9);
  static const cst4 = const Color(0xFF404951);
  static const cst5 = const Color(0xFF1275D9);
}