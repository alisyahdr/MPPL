import 'package:cloud_firestore/cloud_firestore.dart';

class ProyekModel {
  String? nama;
  DateTime? tm;
  DateTime? ts;
  String? alamat;

  ProyekModel({this.nama, this.tm, this.ts, this.alamat});
}
