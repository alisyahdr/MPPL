package id.rain.awatch.awatch

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
